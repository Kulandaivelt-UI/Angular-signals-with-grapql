export const flightNames = [
    "IndiGo",
    "Air India",
    "SpiceJet",
    "Vistara",
    "Go First",
    "AirAsia"
] 

export const timeSlots = ['Morning (6am–12pm)', 'Afternoon (12pm–6pm)', 'Evening (6pm–12am)', 'Night (12am–6am)'];